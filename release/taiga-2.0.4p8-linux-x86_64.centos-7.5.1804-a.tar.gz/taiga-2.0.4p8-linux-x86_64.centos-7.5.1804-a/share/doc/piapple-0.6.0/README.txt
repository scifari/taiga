w10n-sci essentials
