                        Pomegranate README

Pomegranate is a python application that webifies science data files.
in the following formats: netcdf, hdf4, and hdf5.
