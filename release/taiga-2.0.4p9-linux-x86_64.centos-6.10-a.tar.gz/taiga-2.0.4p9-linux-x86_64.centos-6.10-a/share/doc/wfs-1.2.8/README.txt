                             WFS README

WFS is a python implementation of the Webification (w10n) specification
for file system tree.
